// Import existing prompts from prompts.txt to Firebase
// This script parses the prompts.txt file and uploads them to Firestore

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCDsAJx-JUCuKC1-YR16N7APYpTh--SSLo",
  authDomain: "videoprompter-d6a18.firebaseapp.com",
  projectId: "videoprompter-d6a18",
  storageBucket: "videoprompter-d6a18.firebasestorage.app",
  messagingSenderId: "43646976330",
  appId: "1:43646976330:web:6d57b38a3f6c98d4c2c1b3"
};

// Parse prompts.txt content
function parsePromptsFile(content) {
  const lines = content.split('\n');
  const prompts = [];
  let order = 0;
  
  for (const line of lines) {
    // Skip comments and empty lines
    if (line.trim() === '' || line.startsWith('#')) continue;
    
    // Parse format: category|title|prompt|youtubeLink (optional)
    const parts = line.split('|');
    if (parts.length >= 3) {
      const category = parts[0].trim();
      const title = parts[1].trim();
      const prompt = parts[2].trim();
      const youtubeLink = parts[3] ? parts[3].trim() : null;
      
      // Extract custom fields from prompt
      const customFields = extractCustomFields(prompt);
      
      prompts.push({
        category,
        title,
        prompt,
        youtubeLink,
        customFields: customFields.length > 0 ? customFields : null,
        order: order++,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        createdBy: 'import-script',
        updatedBy: 'import-script'
      });
    }
  }
  
  return prompts;
}

// Extract custom fields from prompt text
function extractCustomFields(prompt) {
  const fields = [];
  const fieldMap = new Map();
  
  // Common patterns for custom fields
  const patterns = [
    // Direct placeholders
    { regex: /\{(\w+)\}/g, type: 'placeholder' },
    // SUBJECT/SCENE/ACTION/STYLE/AUDIO pattern
    { regex: /SUBJECT:\s*([^\.]+)\./g, field: 'subject' },
    { regex: /SCENE:\s*([^\.]+)\./g, field: 'scene' },
    { regex: /ACTION:\s*([^\.]+)\./g, field: 'action' },
    { regex: /STYLE:\s*([^\.]+)\./g, field: 'style' },
    { regex: /AUDIO:\s*([^\.]+)\./g, field: 'audio' }
  ];
  
  // Look for {variable} patterns
  const placeholderRegex = /\{(\w+)\}/g;
  let match;
  while ((match = placeholderRegex.exec(prompt)) !== null) {
    const fieldName = match[1];
    if (!fieldMap.has(fieldName)) {
      const label = fieldName.split('_').map(word => 
        word.charAt(0).toUpperCase() + word.slice(1)
      ).join(' ');
      
      fieldMap.set(fieldName, {
        name: fieldName,
        label: label,
        type: 'text'
      });
    }
  }
  
  // Convert map to array
  return Array.from(fieldMap.values());
}

// Load prompts.txt content
const promptsContent = `# Veo 3 Prompts Database
# Format: category|title|prompt|youtubeLink (optional)
# Lines starting with # are comments
# Categories: ads, storytelling, tutorial, vlogging, street-interview, tech-influencer, mobile-game

ads|Product Launch Teaser|8-second cinematic product launch teaser. SUBJECT: Sleek matte black smartphone with angular titanium edges and glowing blue power button positioned center frame. SCENE: Minimalist white infinity backdrop with subtle tech laboratory environment, soft LED panels creating depth, controlled studio lighting. ACTION: Product materializes from particles, rotates smoothly 360 degrees revealing key features, camera slow dolly in as device pulses with blue accent light, final dramatic pause with logo illumination. STYLE: Photorealistic commercial cinematography with shallow depth of field, high contrast lighting, cool blue color temperature. AUDIO: Deep electronic pulse building to dramatic crescendo, subtle tech activation sounds, whoosh effects during rotation. Mysterious, premium, cutting-edge mood. (no subtitles, no on-screen text)|https://youtube.com/watch?v=dQw4w9WgXcQ

ads|Lifestyle Brand Commercial|8-second lifestyle brand commercial. SUBJECT: Woman in late 20s with shoulder-length wavy brown hair, wearing cream cashmere sweater and minimalist gold jewelry, holding branded skincare product with confident grace. SCENE: Bright modern café with floor-to-ceiling windows, warm golden hour sunlight streaming through glass, blurred café patrons and hanging plants creating depth. ACTION: Woman applies product to skin with gentle upward motions, pauses to feel texture, then looks up with genuine satisfied smile directly at camera. STYLE: Handheld documentary style with slight natural movement, warm golden hour cinematography, soft focus background. AUDIO: Gentle acoustic guitar melody, natural café ambience with soft chatter and espresso machine hums, woman's contented sigh. Authentic, aspirational lifestyle mood. (no subtitles)|https://youtube.com/watch?v=dQw4w9WgXcQ

ads|Social Media Ad|8-second vertical social media ad (9:16 aspect ratio). SUBJECT: Content creator in early 20s with vibrant purple-streaked hair in space buns, wearing oversized vintage band t-shirt and chunky rings, energetically showcasing tech gadget. SCENE: Overhead shot of clean white desk setup with ring light above, colorful RGB LED strips creating rainbow backdrop, plants and aesthetic room décor visible. ACTION: Creator grabs product with excitement, demonstrates key feature with exaggerated gestures, then points directly at camera with wide smile and raised eyebrows. STYLE: Fast-paced TikTok aesthetic with quick zoom transitions, vibrant saturated colors, dynamic handheld movement. AUDIO: Upbeat electronic trending music with heavy bass drops, product activation sounds, enthusiastic "Whoa!" exclamation. Energetic, Gen-Z focused, scroll-stopping mood. (no dialogue, optimized for silent viewing)|

ads|IKEA Empty Room Assembly|8-second cinematic furniture assembly magic. SUBJECT: Sealed IKEA cardboard box positioned center frame in empty room, containing complete bedroom furniture set. SCENE: Empty Scandinavian-style room with bright white walls, natural light wood floors, large window with soft daylight filtering through sheer curtains. ACTION: Box trembles and shakes, then bursts open with cardboard dust cloud, furniture pieces float and assemble in fast motion - bed frame, nightstands, lamp, wardrobe materialize, yellow throw blanket gently lands on completed bed. STYLE: Photorealistic 4K cinematography with fixed wide-angle lens, natural lighting, clean minimalist aesthetic. AUDIO: Deep rumbling build-up, sharp cardboard burst with echo, fast-paced ASMR assembly sounds - clicking, sliding, dropping into place, soft fabric landing with satisfied sigh. Magical, satisfying, home transformation mood. (no people, no text)|https://youtu.be/6-bFoPC8Wcw

storytelling|Mystery Short Film Opening|8-second cinematic mystery opening. SUBJECT: Mysterious silhouette of tall figure in long coat appearing briefly in second-floor window of Victorian brick building. SCENE: Empty Victorian street at night with thick fog rolling between vintage iron lampposts, wet cobblestones reflecting amber streetlight, bare tree branches creating ominous shadows. ACTION: Camera slow zoom toward window as fog drifts mysteriously around building, silhouette moves across window frame, then vanishes as curtain falls with sudden movement. STYLE: Film noir cinematography with handheld movement, shallow depth of field, low-key lighting creating dramatic chiaroscuro effects. AUDIO: Suspenseful orchestral strings building tension, distant footsteps echoing on cobblestones, wind rustling through bare branches, subtle window creak. Dark, atmospheric, thriller mood building intrigue. (no subtitles)|https://youtube.com/watch?v=dQw4w9WgXcQ

storytelling|Time-lapse Story|8-second time-lapse story of bustling coffee shop transformation. SUBJECT: Urban coffee shop interior with exposed brick walls, hanging plants, wooden tables, and central barista counter serving as focal point. SCENE: Cozy corner café with large windows showing changing natural light from blue pre-dawn to warm golden sunset, creating dynamic lighting throughout space. ACTION: Staff arrives and prepares equipment in fast motion, morning rush with business people flows in, afternoon laptop workers settle in, evening couples gather, closing routine completes cycle. STYLE: Fixed wide-angle time-lapse cinematography capturing natural light progression, warm color temperature shifts throughout day. AUDIO: Upbeat indie acoustic guitar melody layered with accelerated coffee shop sounds - espresso grinding, milk steaming, animated chatter, door chimes. Warm, community-focused, slice-of-life mood celebrating human connection. (no dialogue)|

storytelling|Emotional Reunion|8-second emotional airport reunion scene. SUBJECT: Young woman in her 20s with long flowing brown hair, wearing casual travel outfit with denim jacket and backpack, expressing anticipation and joy. SCENE: Bright modern airport terminal with large windows showing tarmac, travelers with luggage moving past, digital arrival boards, busy atmosphere with natural fluorescent lighting. ACTION: Woman checks phone nervously while scanning crowd, looks around anxiously, then suddenly lights up with pure joy and runs toward camera with arms outstretched for embrace, transitioning to slow motion. STYLE: Handheld documentary cinematography with natural movement, warm airport lighting, shallow depth of field during emotional climax. AUDIO: Soft piano melody building to emotional crescendo, ambient airport announcements echoing, footsteps on hard floor, woman's joyful gasp. Heartwarming, genuine, uplifting mood capturing raw human connection. (no subtitles)|

tutorial|Cooking Tutorial Style|8-second cooking tutorial with professional overhead technique demonstration. SUBJECT: Skilled hands with natural manicured nails wearing subtle chef's ring, precisely demonstrating rocking knife technique on fresh basil herbs. SCENE: Professional marble kitchen counter with organized mise en place - glass bowls containing ingredients, wooden cutting board, sharp chef's knife, fresh herbs artfully arranged. ACTION: Hands position knife correctly, then perform steady rocking motion chopping herbs into fine chiffonade, movements flow with professional confidence and rhythm. STYLE: Fixed overhead cinematography with even studio lighting eliminating shadows, shallow depth of field focusing on knife work, clean minimalist aesthetic. AUDIO: Rhythmic knife chopping on board, subtle kitchen ambience, no music to focus on technique sounds. Professional, educational, ASMR-style mood. (no music, technique-focused)|https://youtube.com/watch?v=dQw4w9WgXcQ

tutorial|DIY Project Guide|8-second DIY succulent terrarium assembly tutorial. SUBJECT: Creative hands wearing delicate silver rings and earth-tone nail polish, carefully assembling glass terrarium with small succulents. SCENE: Clean white desk workspace with organized craft supplies - clear glass containers, various succulents, decorative river stones, potting soil, small gardening tools arranged aesthetically. ACTION: Hands place drainage layer of stones, add potting soil with small spoon, gently position succulents with tweezers, then add final decorative stone accents. STYLE: Static medium shot with professional softbox lighting eliminating harsh shadows, warm natural color palette, clean minimalist composition. AUDIO: Gentle ambient instrumental music, satisfying material sounds - stones clinking softly, soil rustling, glass tapping. Satisfying, creative, accessible DIY mood inspiring project completion. (no dialogue, process-focused)|

tutorial|Tech Tutorial|8-second tech tutorial demonstrating mobile app navigation. SUBJECT: Clean-cut male presenter in early 30s with black-framed glasses and casual navy polo shirt, holding latest smartphone while explaining interface. SCENE: Modern home office with contemporary desk setup, computer monitor, small plants, minimal décor, professional ring lighting creating even illumination. ACTION: Presenter gestures toward phone screen while demonstrating swipe navigation, finger taps highlighted with subtle animation circles, smooth interface transitions shown clearly. STYLE: Picture-in-picture composition with screen recording overlay, fixed camera with shallow depth of field, professional lighting setup. AUDIO: Clear, confident male voiceover with slight tech enthusiasm, subtle app notification sounds, no background music. Professional, accessible, step-by-step educational mood. (instructional, clear dialogue)|

tutorial|Makeup Tutorial|8-second makeup tutorial demonstrating eyeshadow technique. SUBJECT: Beauty influencer in mid-20s with flawless skin and half-completed glam makeup look, wearing neutral lip color and perfectly shaped brows. SCENE: Aesthetic vanity setup with organized makeup collection, professional brushes, soft pink décor, ring light creating shadow-free illumination. ACTION: Applies warm bronze eyeshadow with fluffy brush using precise upward blending motions, then looks directly at camera with confident smile and final blend. STYLE: Fixed close-up cinematography at eye level, even professional lighting, shallow depth of field on eyes, warm color palette. AUDIO: Upbeat background music, subtle brush-on-skin sounds, clear female voiceover: "This shade is perfect for everyday glam - blend upward for that lifted effect!" Aspirational, beauty-focused, educational mood. (instructional dialogue)|

vlogging|Professional Service Vlog|8-second authentic professional service vlog. SUBJECT: Male mechanic in early 30s with friendly demeanor, slight stubble, dark brown tousled hair, hazel eyes, medium athletic build, wearing navy blue coveralls with embroidered business name, oil-stained hands. SCENE: Well-lit auto repair shop with open bay doors providing natural lighting, car with raised hood, background showing car lifts, organized toolboxes, professional equipment. ACTION: Mechanic gestures toward car engine while explaining, looks directly at camera with confident nod, then wipes hands on shop rag with professional ease. STYLE: Static medium shot vlogging style with natural documentary lighting, authentic workshop atmosphere, real-world setting. AUDIO: Mechanic says (confident, trustworthy tone): "Been fixing cars for fifteen years. Your engine troubles? We'll get you back on the road fast and affordable." Natural shop ambience with distant tool sounds. Professional, trustworthy, authentic service mood.|https://youtube.com/watch?v=dQw4w9WgXcQ

vlogging|IG Influencer Hotel Vlog|8-second luxury travel influencer vlog. SUBJECT: Stylish female influencer in mid-20s with perfectly styled blonde hair, natural glam makeup, wearing trendy casual designer outfit, exuding confidence and excitement. SCENE: Luxury hotel suite with floor-to-ceiling windows showcasing stunning city skyline, modern furnishings, warm natural lighting flooding through windows. ACTION: Influencer adjusts hair gracefully, gestures enthusiastically toward magnificent view, then looks directly at camera with bright, genuine smile. STYLE: Handheld vlogging cinematography with slight authentic movement, bright natural lighting, warm hotel ambience, aspirational aesthetic. AUDIO: Female influencer says (excited, upbeat tone): "Just checked into this incredible suite! The view is absolutely stunning - can't wait to explore the city!" Soft ambient music, distant city sounds. Upbeat, aspirational, lifestyle-focused travel mood.|

vlogging|Tech Product Review Vlog|8-second enthusiastic tech product review. SUBJECT: Male tech reviewer in late 20s with clean-cut appearance, black-framed glasses, wearing casual tech company t-shirt, holding latest flagship smartphone with confident expertise. SCENE: Modern tech setup with RGB lighting, multiple monitors creating colorful backdrop, professional studio environment with warm LED strips providing even illumination. ACTION: Reviewer examines phone carefully, rotates device to showcase different angles and features, then looks directly at camera with genuinely excited expression. STYLE: Close-up cinematography with shallow depth of field, professional studio lighting, tech-focused aesthetic with colorful background elements. AUDIO: Male reviewer says (enthusiastic, informative tone): "This new flagship just dropped and I've been testing it for a week. The camera quality is absolutely game-changing!" Subtle electronic ambient music. Energetic, informative, authentic tech enthusiast mood.|

street-interview|Nighttime City Interview|8-second nighttime street interview scene. SUBJECT: Young male interviewer in casual streetwear holding wireless microphone, engaging with three stylish young women dressed for night out - one brunette, one blonde, one with purple highlights. SCENE: Outside trendy bustling city restaurant with amber and magenta neon glow, wet pavement reflecting colorful lights, pedestrians and passing cars with headlight streaks creating urban energy. ACTION: Interviewer approaches group with microphone, asks question confidently, women respond enthusiastically with animated gestures and genuine reactions. STYLE: Handheld cinema verité documentary style with natural movement, shallow depth of field focusing on expressions, vibrant nighttime urban lighting. AUDIO: Interviewer says (confident tone): "Veo 3. Worth it or not?" Women respond (excited tones): "Yeah!" - "For sure!" - "Yeah, all of this feels so real... even though it isn't!" Urban ambience with traffic, restaurant sounds. Lively, unscripted, authentic street mood.|

tech-influencer|SaaS Product Announcement|8-second tech influencer product announcement. SUBJECT: Caucasian male in mid-20s with wavy brown hair, rectangular glasses, hazel eyes, and stubble, wearing dark crewneck tee, projecting confident authority. SCENE: Cool-toned modern room with soft LED ambient lighting, glowing blue-purple neon sign reading "SaaS MODE" creating tech atmosphere. ACTION: Subject maintains calm smirk while gazing directly into camera, uses natural hand gesticulation with both hands to emphasize points, delivers message with controlled confidence. STYLE: Eye-level front-facing cinematography with professional lighting effects, modern tech influencer aesthetic, cool color palette. AUDIO: Male influencer says (confident, slightly provocative tone): "Gemini CLI is here. And if you're not using it yet... you're already behind." Subtle tech ambience. Professional, authoritative, product launch mood.|

mobile-game|Match-3 Puzzle Game|8-second satisfying match-3 puzzle game advertisement. SUBJECT: Well-manicured hands with colorful nail art holding smartphone in portrait mode, displaying vibrant match-3 puzzle game with cascading gems and candies. SCENE: Clean white gradient background with subtle rainbow light reflections, bright cheerful daylight creating soft shadows, optimized for mobile gaming aesthetic. ACTION: Finger swipes to match 4 colorful gems creating striped candy, taps striped candy for satisfying row explosion with rainbow particles, gems cascade creating automatic chain reactions, level completes with golden confetti celebration. STYLE: Close-up cinematography slightly above eye-level, gentle zoom on successful matches, pull back for victory celebration, bright polished mobile game aesthetic. AUDIO: Satisfying pop sounds with each match, cheerful puzzle music, dramatic victory fanfare. Uplifting and satisfying casual gaming mood. (no dialogue, game-focused)|

mobile-game|Battle Royale Mobile|8-second intense mobile battle royale advertisement. SUBJECT: Focused gamer hands with gaming sleeves gripping smartphone in landscape mode, displaying realistic 3D battle royale with 100 players dropping onto shrinking map. SCENE: Dark gaming setup with RGB lighting strips, dramatic blue and purple ambient lighting creating competitive atmosphere, screen glow illuminating focused expression. ACTION: Intense rapid thumb movements on virtual joysticks for character movement, rapid tapping for shooting enemies with muzzle flashes, building defensive structures with quick gestures, final elimination leading to victory royale celebration with fireworks. STYLE: Dynamic cinematography switching between hands and screen action, slight handheld shake during intense moments, steady for victory celebration, competitive gaming aesthetic. AUDIO: Intense battle music with heavy bass, realistic gunshot effects, dramatic victory anthem. Competitive intensity and adrenaline rush gaming mood. (no dialogue, action-focused)|

mobile-game|Idle Clicker Empire|8-second relaxing idle empire building advertisement. SUBJECT: Relaxed hands holding smartphone in portrait mode, showcasing idle empire building game with automated money generation and satisfying number growth. SCENE: Cozy home environment with warm comfortable ambient lighting, soft furnishings, creating peaceful gaming atmosphere. ACTION: Casual tapping to collect floating money icons with upward animations, swiping through upgrade menus, watching numbers grow exponentially, prestiging for massive multiplier bonus with golden explosion celebration. STYLE: Comfortable viewing angle cinematography showing hands and screen clearly, calm steady shots with gentle focus shifts, warm cozy aesthetic. AUDIO: Satisfying cash register sounds with each collection, gentle background music, achievement chimes. Relaxing satisfaction and steady progression mood. (no dialogue, peaceful progression)|

mobile-game|Hyper Casual Runner|8-second energetic hyper-casual runner advertisement. SUBJECT: Single hand holding smartphone in portrait mode, displaying endless runner with simple one-touch controls and vibrant simplified 3D graphics. SCENE: Bright energetic gradient background matching game colors, vibrant high-energy lighting with dynamic color shifts creating excitement. ACTION: Simple rhythmic thumb tapping to make character jump over obstacles, holding tap for longer jumps and gliding, collecting coins with satisfying magnetic pull effect and sparkles, unlocking new character skin with rainbow burst celebration. STYLE: Focused single-hand cinematography showing gameplay simplicity, bouncy energetic movement matching game rhythm, bright accessible aesthetic. AUDIO: Upbeat electronic music with driving beat, satisfying jumping sound effects, coin collection chimes. Fun, accessible, instantly engaging mood. (no dialogue, rhythm-focused)|

mobile-game|RPG Gacha Collection|8-second epic RPG gacha summoning advertisement. SUBJECT: Excited gamer hands holding premium smartphone in portrait mode, displaying fantasy RPG with character summoning screen and high-quality anime-inspired graphics. SCENE: Mystical purple and gold gradient background with floating magical particles, dramatic fantasy lighting creating magical atmosphere with ethereal glow effects. ACTION: Deliberate tapping to activate summoning portal with magical effects, dramatic reveal of legendary 5-star hero with golden aura and light beams, strategic dragging character into team formation slot with synergy connection lines, battle sequence with spectacular skill animations and victory. STYLE: Focused cinematography on screen during key summoning moments, dramatic zoom during legendary reveal, steady shots for strategy planning, epic fantasy aesthetic. AUDIO: Epic fantasy orchestral music with powerful crescendos, magical summoning sounds, triumphant victory fanfare. Epic adventure with collection excitement mood. (no dialogue, fantasy-focused)|`;

// Function to display import results
function displayImportResults(prompts) {
  console.log('Parsed Prompts:', prompts);
  console.log('Total prompts to import:', prompts.length);
  
  // Group by category
  const categories = {};
  prompts.forEach(prompt => {
    if (!categories[prompt.category]) {
      categories[prompt.category] = [];
    }
    categories[prompt.category].push(prompt);
  });
  
  console.log('\nPrompts by category:');
  Object.entries(categories).forEach(([category, items]) => {
    console.log(`${category}: ${items.length} prompts`);
  });
}

// Parse and display results
const parsedPrompts = parsePromptsFile(promptsContent);
displayImportResults(parsedPrompts);

// Export for use in admin dashboard
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { parsePromptsFile, parsedPrompts };
} else {
  window.parsedPrompts = parsedPrompts;
  window.parsePromptsFile = parsePromptsFile;
}

// Log to confirm script loaded
console.log('Import script loaded. Found', parsedPrompts.length, 'prompts ready to import.');
}