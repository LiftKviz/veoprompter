// Firebase configuration for Veo 3 Prompt Assistant
// You'll need to replace these with your actual Firebase project credentials

export const firebaseConfig = {
  apiKey: "AIzaSyCDsAJx-JUCuKC1-YR16N7APYpTh--SSLo",
  authDomain: "videoprompter-d6a18.firebaseapp.com",
  projectId: "videoprompter-d6a18",
  storageBucket: "videoprompter-d6a18.firebasestorage.app",
  messagingSenderId: "43646976330",
  appId: "1:43646976330:web:6d57b38a3f6c98d4c2c1b3"
};

// Instructions to get these values:
// 1. Go to https://console.firebase.google.com/
// 2. Create a new project or select existing one
// 3. Click on the gear icon > Project settings
// 4. Under "Your apps" section, create a web app
// 5. Copy the configuration values here